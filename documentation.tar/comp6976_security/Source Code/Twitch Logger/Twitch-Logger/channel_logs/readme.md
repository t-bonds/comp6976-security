# Channel Logs
This folder contains the chat logs for the channels you wish to gather data from. Chat logs will be timestamped by its execution time.
